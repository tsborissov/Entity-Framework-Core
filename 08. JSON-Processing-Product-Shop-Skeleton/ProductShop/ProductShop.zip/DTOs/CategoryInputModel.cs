﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
    }
}
